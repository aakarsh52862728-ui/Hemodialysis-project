# Hemodialysis Project

React + Tailwind CDN version.

## Setup

```bash
npm install
npm start
```

## Deploy

Push this folder to GitHub → Import into Vercel → Deploy automatically.
